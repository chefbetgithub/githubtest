### HEYO BANANAS!

The website is made with Next.js + Tailwind CSS Example

Type `yarn` on main folder to install the requirements. `yarn dev` to start running on your computer (localhost:3000).

/image_generation has the python code
/contract has the solidity code for boring bananas co.


Extra links:

Remix IDE: https://remix.ethereum.org

IPFS Command line reference: https://docs.ipfs.io/reference/cli/#ipfs-add

Pinata Cloud: https://pinata.cloud

IPFS to Arweave: https://ipfs2arweave.com/

Opensea Metadata Standard: https://docs.opensea.io/docs/metadata-standards
