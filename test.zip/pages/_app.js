import 'tailwindcss/tailwind.css'
import '../styles/style2.css'
// import '../styles/normalize.css'
// import '../styles/webflow.css'
function MyApp({ Component, pageProps }) {
  return <Component {...pageProps} />
}

export default MyApp
