import Head from 'next/head'
import {useState} from 'react';

import Web3 from "web3";

import {ADDRESS, ABI} from "../config.js"


 async function run() {
    const web3 = new Web3("https://rpc-mumbai.matic.today/");
    const contract = new web3.eth.Contract(ABI, ADDRESS);
    const salam = await contract.methods.totalSupply().call();
    //console.log(salam);
	   //alert("Total "+ salam);
	return salam;
	
}

export default  function Home() {
  
   const [salam,setSalam] = useState('');
  
   run().then(data=>{
    setSalam(data);
   }).catch(err=>{
    console.warn(err.message)
   })
	
	

	


  return (
    <div id="bodyy" className="flex flex-col items-center justify-center min-h-screen py-2">
      <Head>
        <title>MaticPunks - Punks on Matic (Polygon) Blockchain</title>
        <link rel="icon" href="/images/hola.png" />

        <meta property="og:title" content="MaticPunks" key="ogtitle" />
        <meta property="og:description" content="MaticPunks are NFTs on the Polygon(Matic) blockchain. Punks on Matic" key="ogdesc" />
        <meta property="og:type" content="website" key="ogtype" />
        <meta property="og:url" content="https://maticpunks.net/" key="ogurl"/>
        <meta property="og:image" content="https://maticpunks.net/images/Hola.png" key="ogimage"/>
        <meta property="og:site_name" content="https://maticpunks.net/" key="ogsitename" />

        <meta name="twitter:card" content="summary_large_image" key="twcard"/>
        <meta property="twitter:domain" content="maticpunks.net" key="twdomain" />
        <meta property="twitter:url" content="https://maticpunks.net/" key="twurl" />
        <meta name="twitter:title" content="Matic Punks" key="twtitle" />
        <meta name="twitter:description" content="MaticPunks are NFTs on the Polygon(Matic) blockchain. Punks on Matic" key="twdesc" />
        <meta name="twitter:image" content="https://maticpunks.net/images/Hola.png" key="twimage" />
      </Head>


      <div >
          <div className="flex items-center justify-between w-full border-b-2	pb-6">
            <a href="/" className=""><img src="images/maticpunklogo.png" width="250" alt="" className="logo-image" /></a>
            <nav className="flex flex-wrap flex-row justify-around LCDSolid">
              <a href="/mint" className="text-3xl text-black hover:text-black m-6">Get Punk!</a>
              <a href="/mypunks" className="text-3xl text-black hover:text-black m-6">My Punks</a>
              <a href="#contact" className="text-3xl text-black hover:text-black m-6">Contact</a>
              <a href="https://twitter.com/MaticPunks" className="text-3xl  hover:text-black m-6 text-blau">TWITTER</a>
              <a href="https://discord.gg/" className="text-3xl  hover:text-black m-6 text-blau">TELEGRAM</a>
            </nav>
             
          </div>
          
        </div>

        <div className="md:w-2/3 w-4/5 " id="about">
       
        
          <div className="mt-6 border-b-2 py-6">
            <div className="flex flex-wrap lg:flex-nowrap justify-around items-center">
                  <div className="lg:w-1/2 w-3/4">
                    <h1 className="text-5xl LCDSolid text-black ">Own one of <br/> 10,000 unique  <br/><span className="text-blau">Matic Punks</span></h1>
                    <p className="text-2xl text-black my-6  LCDSolid">MaticPunks are NFTs on the Polygon(Matic) blockchain. Each of these 10,000 MaticPunks has attributes that make them unique according to a defined rarity system.  
                    </p>
                    <p className="text-2xl text-black my-6  LCDSolid">
                     ‍
                    <span className="text-black text-2xl LCDSolid"><strong>TOTAL SUPPLY: 10,000</strong> Punks.<br/><strong>PRICE: 100 MATIC </strong>each.</span></p>
                    <br/>

                  </div>
                  <img className="lg:w-2/5 w-3/4" src="images/Hola.png" width="500px" />
            </div>
            <div className="flex flex-col items-center">

            <a href="/mint" className="mt-4 LCDSolid text-4xl border-6 bg-blau  text-white hover:text-black p-2 ">GO TO MINTING PAGE!</a> <br/>
			
			
			
			<span className="text-blau text-5xl LCDSolid">MaticPunks remaining: {salam}/10,000</span>
			
			
			
			     
			
                
                
            </div> 
            </div>



    

                <div id="traits" className="flex flex-wrap justify-around items-center  mx-6 py-6">
                  <div className="border-4 border-purple-400  p-4"><img src="images/gifmaticpunks.gif" alt="" width="400px" className="feature-image"/></div>
                  <div className="flex flex-col justify-between mx-6 sm:w-1/2 w-4/5 py-6 ">
                    <h2 className="text-blau LCDSolid text-4xl text-center">What makes MaticPunks so special ?</h2>
                    <p className="text-xl text-black my-6  LCDSolid">In the interest of fairness and to give everyone the chance to own one (or more) MaticPunks, the purchase is made on a random basis. <br/><br/>

                    The identity of the MaticPunks will remain a mystery until your purchase is completed. No first come, first serve, everyone can have a chance to get a MaticPunks Zombie or a MaticPunks Ape. <br/><br/>

                    The MaticPunks obtained are visible on our interface and will be exchangeable on our social networks or on our marketplace. You can get as many MaticPunks as you want but once the 10,000 are sold it will be too late to get one at mint cost. 
                    </p>
                  </div>
                </div>
                
              

             
      
              <div id="contact" className="flex flex-wrap justify-around items-center  mx-6 py-6">
                  <div className=" p-4"><img src="images/letstalk.png" alt="" width="400px" className="feature-image"/></div>
                  <div className="flex flex-col justify-between mx-6 sm:w-1/2 w-4/5 py-6 ">
                    <h2 className="text-blau LCDSolid text-6xl text-center">CONTACT Matic Punks TEAM</h2>
                    <p className="text-xl text-black my-6  LCDSolid"> We'd love to hear from you! 
                    </p>
                    <p className="text-xl text-black my-6  LCDSolid"> Drop us a line at <a className="text-black underline font-bold" target="_blank" href="mailto:contact@maticpunks.net">contact@maticpunks.net</a>,<br/>
                    or alternatively reach out to us on Twitter <a className="text-black underline font-bold" target="_blank" href="https://twitter.com/MaticPunks">@MaticPunks</a><br/> 
                    Or alternatively, join our <a className="text-black underline font-bold" target="_blank" href="https://discord.gg/">Telegram Group</a>.
                    </p>



                  </div>



                   <p className="text-xl text-black my-6  LCDSolid"> MaticPunks is in no way affiliated with Larva Labs and/or CryptoPunks

                    </p>
       


              </div>   
          </div>  
    </div>  
    )
  }